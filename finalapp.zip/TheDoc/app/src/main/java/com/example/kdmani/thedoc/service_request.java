package com.example.kdmani.thedoc;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class service_request extends Activity {
    ListView myList;
    Button getChoice, clearAll;
    SharedPreferences sharedpreferences;
    String finalResult;
    ProgressDialog progressDialog;

    public static final String MyPREFERENCES = "MyUserChoice";
    ArrayList<String> selectedItems = new ArrayList<String>();
    String id;
    HashMap<String, String> hashMap = new HashMap<>();
    HttpParse httpParse = new HttpParse();
    String HttpURL = "https://radhathangam3.000webhostapp.com/servicerequest.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_request);
        if (getIntent() != null) {
            id = getIntent().getStringExtra("id");
        }
        myList = (ListView) findViewById(R.id.list);
        getChoice = (Button) findViewById(R.id.getchoice);
        clearAll = (Button) findViewById(R.id.clearall);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, getResources().getStringArray(R.array.Tests));
        myList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        myList.setAdapter(adapter);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        if (sharedpreferences.contains(MyPREFERENCES)) {
            LoadSelections();
        }
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });

        getChoice.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                String selected = "";
                int cntChoice = myList.getCount();

                SparseBooleanArray sparseBooleanArray = myList.getCheckedItemPositions();
                for (int i = 0; i < cntChoice; i++) {
                    if (sparseBooleanArray.get(i)) {
                        selected += myList.getItemAtPosition(i).toString() + ",";
                        System.out.println("Checking list while adding:" + myList.getItemAtPosition(i).toString());
                        SaveSelections();
                    }

                }
                String selectItem = selected.substring(0, selected.length() - 1);
                onRequest(selectItem);

            }
        });

        clearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClearSelections();
            }
        });

    }

    private void SaveSelections() {
// save the selections in the shared preference in private mode for the user
        SharedPreferences.Editor prefEditor = sharedpreferences.edit();
        String savedItems = getSavedItems();
        prefEditor.putString(MyPREFERENCES.toString(), savedItems);
        prefEditor.commit();
    }

    private String getSavedItems() {
        String savedItems = "";
        int count = this.myList.getAdapter().getCount();
        for (int i = 0; i < count; i++) {
            if (this.myList.isItemChecked(i)) {
                if (savedItems.length() > 0) {
                    savedItems += "," + this.myList.getItemAtPosition(i);
                } else {
                    savedItems += this.myList.getItemAtPosition(i);
                }
            }
        }
        return savedItems;
    }

    public void UserRegisterFunction(final String savedItems) {
        class UserRegisterFunctionClass extends AsyncTask<String, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(service_request.this, "Loading Data", null, true, true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {
                super.onPostExecute(httpResponseMsg);
                progressDialog.dismiss();
                Intent intent = new Intent(service_request.this, NewPatientHomeActivity.class);
                startActivity(intent);
                Toast.makeText(service_request.this, httpResponseMsg.toString(), Toast.LENGTH_LONG).show();
                String item=httpResponseMsg.toString();
            }

            @Override
            protected String doInBackground(String... params) {
                hashMap.put("savedItem", params[0]);
                //li = (ListView) findViewById(R.id.list);

                // sp1 = String.valueOf(s1.getSelectedItem());
                //   Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
                //if (.contentEquals("In-Patient")) {

                finalResult = httpParse.postRequest(hashMap, HttpURL);
                // }


                return finalResult;
            }
        }
    }

    public void onRequest(String selectItem){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://radhathangam3.000webhostapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        Call<ResponseBody> call = service.serviceRequest(selectItem,PrefUtils.getFromPrefs(service_request.this,Config.ID,"1"));
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        Toast.makeText(service_request.this, ""+response.body().string(), Toast.LENGTH_SHORT).show();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
    private void LoadSelections() {
// if the selections were previously saved load them

        if (sharedpreferences.contains(MyPREFERENCES.toString())) {

            String savedItems = sharedpreferences.getString(MyPREFERENCES.toString(), "");
            selectedItems.addAll(Arrays.asList(savedItems.split(",")));
            System.out.println("selectedItems:"+selectedItems);
            int count = this.myList.getAdapter().getCount();

            for (int i = 0; i < count; i++) {
                String currentItem = (String) myList.getAdapter()
                        .getItem(i);
                if (selectedItems.contains(currentItem)) {
                    myList.setItemChecked(i, true);
                    Toast.makeText(getApplicationContext(),
                            "Current Item: " + currentItem,
                            Toast.LENGTH_LONG).show();
                } else {
                    myList.setItemChecked(i, false);
                }
            }
        }
    }
    private void ClearSelections (){
// user has clicked clear button so uncheck all the items
        int count = this.myList.getAdapter().getCount();
        for (int i = 0; i < count; i++) {
            this.myList.setItemChecked(i, false);
        }
// also clear the saved selections
        SaveSelections();
    }
}





