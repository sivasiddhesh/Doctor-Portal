package com.example.kdmani.thedoc;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Belal on 1/23/2018.
 */

public class outpatient1 extends Fragment {

    TextView textView;
    TextView complaints;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_medical_detail, null);
        textView = (TextView) view.findViewById(R.id.textView);
        complaints = (TextView) view.findViewById(R.id.complaints);
        if (getActivity().getIntent() != null) {
            String id = getActivity().getIntent().getStringExtra("id");
            onRequest(id);
            onRequestCompalints();
        }
        return view;

    }
    public void onRequest(String id) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://radhathangam3.000webhostapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        Call<ResponseBody> call = service.serviceGetRequest(id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        String[] split = response.body().string().split(",");
                        String data = null;
                        for (int i = 0; i < split.length; i++) {
                            data += "\n"+split[i];
                            String values = data.replaceAll("null", "");
                            textView.setText(values);
                        }


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
    public void onRequestCompalints() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://radhathangam3.000webhostapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        Call<ResponseBody> call = service.complaintRegRequest(PrefUtils.getFromPrefs(getActivity(),Config.ID,"1"));
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        complaints.setText(response.body().string());


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}