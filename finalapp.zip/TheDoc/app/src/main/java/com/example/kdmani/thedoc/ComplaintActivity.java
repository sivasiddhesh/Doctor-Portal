package com.example.kdmani.thedoc;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ComplaintActivity extends AppCompatActivity {

    Button b1;
    EditText name;
    String name_Holder;
    String finalResult,id;
    HttpParse httpParse = new HttpParse();
    ProgressDialog progressDialog;
    HashMap<String, String> hashMap = new HashMap<>();
    Boolean CheckEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        b1 = (Button) findViewById(R.id.button11);
        name = (EditText) findViewById(R.id.editText9);
        if (getIntent() != null) {
            id = getIntent().getStringExtra("id");
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checking whether EditText is Emptyf or Not
                if (!name.getText().toString().equals("")) {
                    onRequest("complaint", name.getText().toString());
                }else {
                    Toast.makeText(ComplaintActivity.this, "Complaints should not be empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

      /*  b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Toast.makeText(getApplicationContext(), "SAVED", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ComplaintActivity.this, NewPatientHomeActivity.class);
                startActivity(intent);
            }
        });

    }*/


    public void CheckEditTextIsEmptyOrNot() {
        name_Holder = name.getText().toString();


        if (TextUtils.isEmpty(name_Holder)) {
            CheckEditText = false;
        } else {
            CheckEditText = true;
        }
    }

    public void UserRegisterFunction(final String name) {
        class UserRegisterFunctionClass extends AsyncTask<String, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {
                super.onPostExecute(httpResponseMsg);
                progressDialog.dismiss();
                Intent intent = new Intent(ComplaintActivity.this, NewPatientHomeActivity.class);
                startActivity(intent);
                Toast.makeText(ComplaintActivity.this, httpResponseMsg.toString(), Toast.LENGTH_LONG).show();
                String item=httpResponseMsg.toString();
            }

            @Override
            protected String doInBackground(String... params) {
                hashMap.put("name_Holder", params[0]);

                String HttpURL = "https://radhathangam3.000webhostapp.com/complaints.php";
                finalResult = httpParse.postRequest(hashMap, HttpURL);
                return finalResult;


            }
        }
        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(name);
    }

    public void onRequest(String type,String name) {
        progressDialog = ProgressDialog.show(ComplaintActivity.this, "Loading Data", null, true, true);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://radhathangam3.000webhostapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        Call<ResponseBody> call = service.complaint(name,PrefUtils.getFromPrefs(ComplaintActivity.this,Config.ID,"1"));
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        progressDialog.dismiss();
                        Toast.makeText(ComplaintActivity.this, ""+response.body().string(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                progressDialog.dismiss();
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}