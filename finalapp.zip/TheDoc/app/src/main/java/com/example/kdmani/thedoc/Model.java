package com.example.kdmani.thedoc;

/**
 * Created by Kd Mani on 2/21/2018.
 */

class Model {
    String name;

    Model(String name){
        this.name = name;

    }
    public String getName(){
        return this.name;
    }
}
