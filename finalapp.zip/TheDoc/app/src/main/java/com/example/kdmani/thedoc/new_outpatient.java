package com.example.kdmani.thedoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class new_outpatient extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_outpatient);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        Button b1;
       b1 = (Button)findViewById(R.id.button13);
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
                public void onClick(View arg0) {
                    Toast.makeText(getApplicationContext(), "New Patient", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent( new_outpatient.this, NewPatientHomeActivity.class);

                    startActivity(intent);
                }
            });
        }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    }
