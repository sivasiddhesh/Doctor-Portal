package com.example.kdmani.thedoc;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class prescription extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    Button save;

    Button next;

    Spinner s2,s3;

    String id;
    CheckBox checkBox1;
    CheckBox checkBox2;
    CheckBox checkBox3;
    CheckBox checkBox4;
    CheckBox checkBox5;

    String BF;
    String AF;
    String M;
    String A;
    String N;
    EditText editText8;
    String type;
    String medicine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);
        s2 = (Spinner)findViewById(R.id.spinner1);
        s3 = (Spinner)findViewById(R.id.spinner2);
        checkBox1 = (CheckBox)findViewById(R.id.checkBox1);
        checkBox2 = (CheckBox)findViewById(R.id.checkBox2);
        checkBox3 = (CheckBox)findViewById(R.id.checkBox3);
        checkBox4 = (CheckBox)findViewById(R.id.checkBox4);
        checkBox5 = (CheckBox)findViewById(R.id.checkBox5);
        editText8 = (EditText) findViewById(R.id.editText8);
        checkBox1.setOnCheckedChangeListener(this);
        checkBox2.setOnCheckedChangeListener(this);
        checkBox3.setOnCheckedChangeListener(this);
        checkBox4.setOnCheckedChangeListener(this);
        checkBox5.setOnCheckedChangeListener(this);

       s2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
               type = String.valueOf(s2.getSelectedItem());
               if(type.contains("Insulin")) {
                   ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(prescription.this,
                           android.R.layout.simple_spinner_item,getResources().getStringArray(R.array.Insulin));
                   dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                   dataAdapter.notifyDataSetChanged();
                   s3.setAdapter(dataAdapter);
               }
               if(type.contains("Tablet")) {
                   ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(prescription.this,
                           android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Tablet));
                   dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                   dataAdapter2.notifyDataSetChanged();
                   s3.setAdapter(dataAdapter2);

               }
           }

           @Override
           public void onNothingSelected(AdapterView<?> adapterView) {

           }
       });
       s3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

               medicine = adapterView.getAdapter().getItem(i).toString();
           }

           @Override
           public void onNothingSelected(AdapterView<?> adapterView) {

           }
       });


        next=(Button)findViewById(R.id.button9);
        save=(Button)findViewById(R.id.button10);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                String intake = BF + "," + AF + "," + M + "," + A + "," + N;
                onRequest(medicine,type,intake,editText8.getText().toString());
                /*    Toast.makeText(getApplicationContext(), "DONE", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(prescription.this, prescription.class);
                    startActivity(intent);*/
                }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                String intake = BF + "," + AF + "," + M + "," + A + "," + N;
                onRequest(medicine,type,intake,editText8.getText().toString());
                /*    Toast.makeText(getApplicationContext(), "DONE", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(prescription.this, prescription.class);
                    startActivity(intent);*/
            }
        });


    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }





    public void onRequest(String medicine,String type,String intake,String duration){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://radhathangam3.000webhostapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        String id = PrefUtils.getFromPrefs(prescription.this,Config.ID,"1");
        Call<ResponseBody> call = service.prescription(medicine,type,intake,duration,id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        Toast.makeText(prescription.this, ""+response.body().string(), Toast.LENGTH_SHORT).show();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        switch (compoundButton.getId()){
            case R.id.checkBox1:
                if (isChecked) {
                    BF="BF";
                }else{
                    BF="";
                }
                break;
            case R.id.checkBox2:
                if (isChecked) {
                    AF="AF";
                }else{
                    AF="";
                }
                break;
            case R.id.checkBox3:
                if (isChecked) {
                    M="M";
                }else{
                    M="";
                }
                break;
            case R.id.checkBox4:
                if (isChecked) {
                    A="A";
                }else{
                    A="";
                }
                break;
            case R.id.checkBox5:
                if (isChecked) {
                    N="N";
                }else{
                    N="";
                }
                break;
        }

    }
}
