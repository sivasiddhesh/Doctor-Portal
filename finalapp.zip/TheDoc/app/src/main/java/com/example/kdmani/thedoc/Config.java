package com.example.kdmani.thedoc;

/**
 * Created by admin on 04-04-2018.
 */

public class Config {

    public static final String ID="id";
}
