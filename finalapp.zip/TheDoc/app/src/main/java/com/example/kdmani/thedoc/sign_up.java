package com.example.kdmani.thedoc;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.HashMap;

public class sign_up extends AppCompatActivity {

    Button register;
    EditText username, email, password, reppassword ;
    String u_name_Holder, email_Holder, passwordHolder, reppasswordHolder;
    String finalResult ;
    String HttpURL = "https://radhathangam3.000webhostapp.com/userreg.php";
    Boolean CheckEditText ;
    ProgressDialog progressDialog;
    HashMap<String,String> hashMap = new HashMap<>();
    HttpParse httpParse = new HttpParse();

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        //Assign Id'S
        username = (EditText)findViewById(R.id.editText3);
        email = (EditText)findViewById(R.id.editText4);
        password = (EditText)findViewById(R.id.editText5);
        reppassword = (EditText)findViewById(R.id.editText6);
        register = (Button)findViewById(R.id.button2);
       getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       getSupportActionBar().setDisplayShowHomeEnabled(true);
        //Adding Click Listener on button.
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checking whether EditText is Emptyf or Not
                CheckEditTextIsEmptyOrNot();
                if (CheckEditText) {
                    // If EditText is not empty and CheckEditT  ext = True then this block will execute.
                    UserRegisterFunction(u_name_Holder, email_Holder, passwordHolder, reppasswordHolder);
                } else {
                    // If EditText is empty then this block will execute .
                    Toast.makeText(sign_up.this, "Please fill all form fields.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void CheckEditTextIsEmptyOrNot(){
        u_name_Holder = username.getText().toString();
        email_Holder = email.getText().toString();
        passwordHolder = password.getText().toString();
        reppasswordHolder= reppassword.getText().toString();
        if(TextUtils.isEmpty(u_name_Holder) || TextUtils.isEmpty(email_Holder) || TextUtils.isEmpty(passwordHolder) || TextUtils.isEmpty(reppasswordHolder))
        {
            CheckEditText = false;
        }
        else {
            CheckEditText = true ;
        }
    }
    public void UserRegisterFunction(final String u_name, final String email, final String password, final String reppassword){
        class UserRegisterFunctionClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(sign_up.this,"Loading Data",null,true,true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {
                super.onPostExecute(httpResponseMsg);
                progressDialog.dismiss();
                if (password.equals(reppassword)) {
                    Intent intent = new Intent(sign_up.this, LoginActivity.class);
                    startActivity(intent);
                    Toast.makeText(sign_up.this,"Registered Successfully", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(sign_up.this, "Incorrect Password", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            protected String doInBackground(String... params) {
                hashMap.put("u_name",params[0]);
                hashMap.put("email",params[1]);
                hashMap.put("password",params[2]);
                hashMap.put("reppassword",params[3]);
                finalResult = httpParse.postRequest(hashMap, HttpURL);
                return finalResult;
            }
        }

        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(u_name,email,password,reppassword);

    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}