package com.example.kdmani.thedoc;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by admin on 26-03-2018.
 */

public interface APIService {

    @FormUrlEncoded
    @POST("/servicerequest.php")
    Call<ResponseBody> serviceRequest(@Field("savedItems") String savedItems,@Field("id") String id);

    @FormUrlEncoded
    @POST("/complaints.php")
    Call<ResponseBody> complaint(@Field("data") String data,@Field("id") String id);


    @FormUrlEncoded
    @POST("/prescription.php")
    Call<ResponseBody> prescription(@Field("medicine") String medicine,@Field("type") String type,@Field("intake") String intake,@Field("duration") String duration,@Field("id") String id);

    @FormUrlEncoded
    @POST("/patientreg.php")
    Call<ResponseBody> PatientRegRequest(@Field("name") String name,@Field("age") String age,@Field("mobile") String mobile,@Field("sex") String sex);


    @GET("/prescription.php")
    Call<ResponseBody> fetchPrescription(@Query("id") String id);

    @FormUrlEncoded
    @POST("/Outpatientreg.php")
    Call<ResponseBody> OutPatientRegRequest(@Field("name") String name,@Field("age") String age,@Field("mobile") String mobile,@Field("sex") String sex);


    @GET("/complaints.php")
    Call<ResponseBody> complaintRegRequest(@Query("id") String id);

    @GET("/servicerequest.php")
    Call<ResponseBody> serviceGetRequest(@Query("id") String id);
}
