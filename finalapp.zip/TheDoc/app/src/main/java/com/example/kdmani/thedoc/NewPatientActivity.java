package com.example.kdmani.thedoc;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.BottomSheetDialog;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NewPatientActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    Spinner s1;
    Button register;
    EditText name, age, mobile;
    String name_Holder, age_Holder, mobile_holder;
    String finalResult;
    private static final int FROM_CAMERA = 1;
    private static final int FROM_GALLERY = 2;
    // String HttpURL = "l";
    Boolean CheckEditText;
    ProgressDialog progressDialog;
    HashMap<String, String> hashMap = new HashMap<>();
    HttpParse httpParse = new HttpParse();
    SwitchCompat mSwitch;
    String mSex = "Female";
    private String camPicPath;
    private static final int IMAGE_SIZE = 100 * 1024;

    ImageView imageUpload;
    Button upload;
    private File mCurrentPhotoFile = null;
    public static final String MULTIPART_FORM_DATA = "multipart/form-data";
    public String picPath="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpatient);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        name = (EditText) findViewById(R.id.editText7);
        imageUpload = (ImageView) findViewById(R.id.imageUpload);
        upload = (Button) findViewById(R.id.upload);
        age = (EditText) findViewById(R.id.editText21);
        mobile = (EditText) findViewById(R.id.editText20);
        register = (Button) findViewById(R.id.button8);
        s1 = (Spinner) findViewById(R.id.spinner3);
        mSwitch = (SwitchCompat) findViewById(R.id.switch_compat);
        mSwitch.setOnCheckedChangeListener(this);
        String sp1 = String.valueOf(s1.getSelectedItem());

        if (sp1.contentEquals("In-Patient")) {
            // Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
            String l = "https://radhathangam3.000webhostapp.com/patientreg.php";
        } else {
            //  Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
            String l = "https://radhathangam3.000webhostapp.com/Outpatientreg.php";
        }


        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialogImageUpload();
            }
        });
        //Adding Click Listener on button.

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checking whether EditText is Emptyf or Not
                CheckEditTextIsEmptyOrNot();
                if (CheckEditText) {
                    s1 = (Spinner) findViewById(R.id.spinner3);

                    String sp1 = String.valueOf(s1.getSelectedItem());
                    if (sp1.contentEquals("In-Patient")) {
                        onRequest("inpatient",name_Holder, age_Holder, mobile_holder, mSex);
                    }else {
                        onRequest("out",name_Holder, age_Holder, mobile_holder, mSex);
                    }
                    // If EditText is not empty and CheckEditT  ext = True then this block will execute.

                } else {
                    // If EditText is empty then this block will execute .
                    Toast.makeText(NewPatientActivity.this, "Please fill all form fields.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void CheckEditTextIsEmptyOrNot() {
        name_Holder = name.getText().toString();
        age_Holder = age.getText().toString();
        mobile_holder = mobile.getText().toString();

        if (TextUtils.isEmpty(name_Holder) || TextUtils.isEmpty(age_Holder) || TextUtils.isEmpty(mobile_holder)) {
            CheckEditText = false;
        } else {
            CheckEditText = true;
        }
    }

    public void UserRegisterFunction(final String name, final String age, final String mobile, final String mSex) {
        class UserRegisterFunctionClass extends AsyncTask<String, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {
                super.onPostExecute(httpResponseMsg);
                progressDialog.dismiss();
                Intent intent = new Intent(NewPatientActivity.this, NewPatientHomeActivity.class);
                startActivity(intent);
                Toast.makeText(NewPatientActivity.this, httpResponseMsg.toString(), Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {
                hashMap.put("name", params[0]);
                hashMap.put("age", params[1]);
                hashMap.put("mobile", params[2]);
                hashMap.put("sex", params[3]);
                s1 = (Spinner) findViewById(R.id.spinner3);

                String sp1 = String.valueOf(s1.getSelectedItem());
                //   Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
                if (sp1.contentEquals("In-Patient")) {
                    String HttpURL = "https://radhathangam3.000webhostapp.com/patientreg.php";
                    finalResult = httpParse.postRequest(hashMap, HttpURL);
                } else {
                    String HttpURL = "https://radhathangam3.000webhostapp.com/Outpatientreg.php";
                    finalResult = httpParse.postRequest(hashMap, HttpURL);
                }


                return finalResult;
            }
        }

        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(name, age, mobile,mSex);

    }


    public void onRequest(String type,String name,String age,String mobile,String sex){
        progressDialog = ProgressDialog.show(NewPatientActivity.this, "Loading Data", null, true, true);
        String url = null;
        if (type.equals("inpatient")) {
            url="https://radhathangam3.000webhostapp.com";
        }else{
            url="https://radhathangam3.000webhostapp.com";
        }
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        APIService service = retrofit.create(APIService.class);
        Call<ResponseBody> call = null;
        if (type.equals("inpatient")) {
            call = service.PatientRegRequest(name,age,mobile,sex);
        }else {
            call = service.OutPatientRegRequest(name,age,mobile,sex);
        }
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        progressDialog.dismiss();
                        PrefUtils.saveToPrefs(NewPatientActivity.this,Config.ID,response.body().string());
                        Intent intent = new Intent(NewPatientActivity.this, NewPatientHomeActivity.class);
                        intent.putExtra("id",response.body().string());
                        startActivity(intent);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
                progressDialog.dismiss();
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        if (isChecked) {
            mSex = "Male";
        } else {
            mSex = "Female";
        }

    }

    public void showDialogImageUpload(){
        final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(NewPatientActivity.this);
        View sheetView = getLayoutInflater().inflate(R.layout.dialog_camera_gallery, null);
        mBottomSheetDialog.setContentView(sheetView);
        mBottomSheetDialog.show();
        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mBottomSheetDialog.dismiss();
            }
        });
        LinearLayout camera = (LinearLayout) sheetView.findViewById(R.id.camera);
        LinearLayout gallery = (LinearLayout) sheetView.findViewById(R.id.gallery);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String state = Environment.getExternalStorageState();
                if (Environment.MEDIA_MOUNTED.equals(state)) {
                    camPicPath = getSavePicPath();
                    openCamera(NewPatientActivity.this, camPicPath);
                }
            }
        });


        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String state = Environment.getExternalStorageState();
                if (Environment.MEDIA_MOUNTED.equals(state)) {
                    openGallery();
                }
            }
        });


    }

    public void openCamera(Context context, String camPicPath){
        Intent openCameraIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        Uri uri = FileProvider.getUriForFile(NewPatientActivity.this,
                BuildConfig.APPLICATION_ID + ".fileprovider",
                new File(camPicPath));
        // Uri uri = Uri.fromFile(new File(camPicPath));
        openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(openCameraIntent,
                FROM_CAMERA);
    }
    public void openGallery(){
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            intent.setAction(Intent.ACTION_GET_CONTENT);
        } else {
            intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra("crop", "true");
            intent.putExtra("scale", "true");
            intent.putExtra("scaleUpIfNeeded", true);
        }
        intent.setType("image/*");
        startActivityForResult(intent,
                FROM_GALLERY);
    }
    public String getSavePicPath() {
        final String dir = FileSaveUtil.SD_CARD_PATH + "image_data/";
        try {
            FileSaveUtil.createSDDirectory(dir);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String fileName = String.valueOf(System.currentTimeMillis() + ".png");
        return dir + fileName;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {

            switch (requestCode) {
                case FROM_CAMERA:
                    FileInputStream is = null;
                    try {
                        is = new FileInputStream(camPicPath);
                        File camFile = new File(camPicPath);
                        if (camFile.exists()) {
                            picPath = camPicPath;
                            Glide.with(NewPatientActivity.this).load(camFile).into(imageUpload);
                        } else {
                            Toast.makeText(NewPatientActivity.this, "Toast!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } finally {

                        try {
                            is.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case FROM_GALLERY:
                    Uri uri = data.getData();
                    String path = FileSaveUtil.getPath(getApplicationContext(), uri);
                    mCurrentPhotoFile = new File(path);
                    if (mCurrentPhotoFile.exists()) {
                        picPath = path;
                        Glide.with(NewPatientActivity.this).load(mCurrentPhotoFile).into(imageUpload);
                    } else {
                        Toast.makeText(NewPatientActivity.this, "File Does Not Exist!", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(NewPatientActivity.this, "Canceled!", Toast.LENGTH_SHORT).show();
        }
    }

}
