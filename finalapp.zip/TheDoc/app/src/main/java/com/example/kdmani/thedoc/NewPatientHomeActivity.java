package com.example.kdmani.thedoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;

public class NewPatientHomeActivity extends AppCompatActivity implements View.OnClickListener {
    private CardView complaints,service,prescription;
    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpatient_home);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (getIntent() != null) {
            id = getIntent().getStringExtra("id");
        }

        complaints = (CardView) findViewById(R.id.complaints);
        service = (CardView) findViewById(R.id.service);
        prescription = (CardView) findViewById(R.id.prescription);

        complaints.setOnClickListener(this);
        service.setOnClickListener(this);
        prescription.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()) {
            case R.id.complaints : i = new Intent(this,ComplaintActivity.class);startActivity(i); break;
            case R.id.prescription : i = new Intent(this,prescription.class);i.putExtra("id",id);startActivity(i); break;
            case R.id.service : i = new Intent(this,service_request.class); i.putExtra("id",id);startActivity(i); break;
            default: break;


        }

    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}


