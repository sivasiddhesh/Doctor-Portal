package com.example.kdmani.thedoc;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class outpatient2 extends Fragment {
    private static String idNumber;
    RequestQueue requestQueue ;
    JsonArrayRequest RequestOfJSonArray ;
    String HTTP_JSON_URL = "https://radhathangam3.000webhostapp.com/id1.php";

    String T ;
    TextView id,name,age,mobile,sexTextView;

    @Nullable
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_personal_details, container, false);
        idNumber = getActivity().getIntent().getStringExtra("id");
        id = (TextView) view.findViewById(R.id.textView5);
        name = (TextView) view.findViewById(R.id.textView6);
        age = (TextView) view.findViewById(R.id.textView7);
        mobile = (TextView) view.findViewById(R.id.textView8);
        sexTextView = (TextView) view.findViewById(R.id.sexTextView);

        JSON_HTTP_CALL(idNumber);
        return view;
    }


    public void JSON_HTTP_CALL(String idNumber){
        String url = HTTP_JSON_URL + "?id=" + idNumber;
        RequestOfJSonArray = new JsonArrayRequest(url,

                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        ParseJSonResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        requestQueue = Volley.newRequestQueue(getActivity());

        requestQueue.add(RequestOfJSonArray);
    }


    public void ParseJSonResponse(JSONArray array){

        for(int i = 0; i<array.length(); i++) {

            DataAdapter GetDataAdapter2 = new DataAdapter();

            JSONObject json = null;
            try {

                json = array.getJSONObject(i);

                id.setText(json.getString("id"));
                name.setText(json.getString("Name"));
                age.setText(json.getString("age"));
                mobile.setText(json.getString("contact"));
                sexTextView.setText(json.getString("sex"));
                System.out.println(json);


            } catch (JSONException e) {

                e.printStackTrace();
            }

        }


    }
}
